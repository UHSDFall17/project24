/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.trollo_gary;

import java.sql.Connection;
import java.util.Scanner;

/**
 *
 * @author Gc PC
 */
public class Trello {

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        dbProcess process = new dbProcess();
        // TODO code application logic here
       System.out.println("Welecome to Trello.");
       Scanner reader = new Scanner(System.in);  // Reading from System.in
        System.out.println("Please select the action: %/n ");
        int a = reader.nextInt(); // Scans the next token of the input as an int.
        //once finished
 
        
        
        switch(a){
            case 1:
                 System.out.println("Create a Task");
                 task new_task = new task();
                 Scanner in = new Scanner(System.in);

                 System.out.println("Task Name: ");
                 String task_name = in.nextLine();
                 new_task.setTask_name(task_name);
                 //System.out.println(new_task.getTask_name());
                
//                 System.out.println("List Name : ");
//                 String list_name = in.nextLine();
//                 new_task.setList_name(list_name);
                 //System.out.println(new_task.getList_name());
                 
                 System.out.println("Task_Comments : ");
                 String task_comment = in.nextLine();
                 new_task.setTask_comment(task_comment);
                 System.out.println(new_task.getTask_comment()); 
                 reader.close();
                 
                 if(new_task.getTask_name()!=null){
                     
                 }
                 
                 process.connect();
                 //String test = "SELECT MAX(APPID) FROM A";
                 //process.executeCreateQuery(test);
                 //process.findId("SID", "A");
                 process.insertTask("aa", "bb");
                 
                 //dbProcess.insertTask(new_task.getTask_name(),new_task.getTask_comment());
                 
                break;
                
            case 2: 
            
                break;
                
            case 3:
                
                break;
                
            case 4:
                
                break;
        }
       
    }
    
}